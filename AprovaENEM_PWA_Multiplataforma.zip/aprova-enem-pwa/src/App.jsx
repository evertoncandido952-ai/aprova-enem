import React, { useEffect, useMemo, useState } from "react";
import {
  BookOpen, LayoutDashboard, CalendarDays, Brain, FileText, BarChart3,
  Target, Flame, Trophy, Clock3, CheckCircle2, Circle, Play, Search,
  Bookmark, BookmarkCheck, ChevronRight, Menu, X, Plus, Trash2, RotateCcw,
  Lightbulb, GraduationCap, NotebookPen, Timer, Sparkles, Save, House
} from "lucide-react";

/*
  APROVA ENEM — interface React responsiva.
  Dependências: react, react-dom, lucide-react.
  Estilização: Tailwind CSS.
  Os dados iniciais de questões são demonstrativos. Para usar questões oficiais,
  adicione um banco licenciado/conferido. A estimativa de desempenho não é nota TRI.
*/

const INITIAL_USER = {
  name: "Estudante",
  targetCourse: "seu curso dos sonhos",
  targetUniversity: "sua universidade",
  targetScore: 800,
  dailyHoursGoal: 3,
  availableDays: ["Segunda", "Terça", "Quarta", "Quinta", "Sexta"],
  xp: 120,
  streak: 3,
  completedSessions: 0,
  studyMinutes: 0,
};

const QUESTION_BANK = [
  {
    id: 1, area: "Matemática", subject: "Matemática", topic: "Porcentagem",
    difficulty: "Fácil", year: "Inédita",
    statement: "Uma mochila custa R$ 200,00 e recebeu desconto de 15%. Qual é o preço após o desconto?",
    options: ["R$ 150,00", "R$ 160,00", "R$ 170,00", "R$ 175,00", "R$ 185,00"],
    correct: 2,
    explanation: "15% de 200 = 0,15 × 200 = 30. Então, 200 − 30 = R$ 170,00."
  },
  {
    id: 2, area: "Ciências Humanas", subject: "História", topic: "Brasil República",
    difficulty: "Médio", year: "Inédita",
    statement: "A política conhecida como coronelismo, durante a Primeira República, estava relacionada principalmente:",
    options: [
      "À participação política igualitária de toda a população.",
      "Ao poder local de grandes proprietários e ao controle do voto.",
      "À escolha direta dos presidentes por voto universal.",
      "À ausência de influência econômica nas eleições.",
      "À autonomia política dos trabalhadores urbanos."
    ],
    correct: 1,
    explanation: "O coronelismo envolvia o poder dos chefes políticos locais, geralmente grandes proprietários, que influenciavam eleições e relações de dependência."
  },
  {
    id: 3, area: "Linguagens", subject: "Português", topic: "Interpretação de texto",
    difficulty: "Médio", year: "Inédita",
    statement: "Em uma campanha de vacinação, o uso de dados estatísticos e de linguagem objetiva tem como finalidade principal:",
    options: [
      "Criar humor por meio de ambiguidades.",
      "Dificultar a compreensão da mensagem.",
      "Dar credibilidade à informação e orientar o público.",
      "Substituir totalmente os argumentos por imagens.",
      "Apresentar uma narrativa ficcional."
    ],
    correct: 2,
    explanation: "Dados e linguagem objetiva ajudam a sustentar a mensagem e podem aumentar a confiança do público nas orientações."
  },
  {
    id: 4, area: "Ciências da Natureza", subject: "Biologia", topic: "Ecologia",
    difficulty: "Fácil", year: "Inédita",
    statement: "Em uma cadeia alimentar, os organismos produtores são aqueles que:",
    options: [
      "Obtêm energia exclusivamente de outros animais.",
      "Decompõem restos orgânicos.",
      "Produzem matéria orgânica, geralmente por fotossíntese.",
      "Ocupam sempre o último nível trófico.",
      "Não participam do fluxo de energia."
    ],
    correct: 2,
    explanation: "Produtores, como plantas e algas, formam matéria orgânica a partir de substâncias inorgânicas, geralmente usando energia luminosa."
  },
  {
    id: 5, area: "Matemática", subject: "Matemática", topic: "Função afim",
    difficulty: "Médio", year: "Inédita",
    statement: "Uma corrida de aplicativo cobra R$ 6,00 de tarifa fixa mais R$ 2,00 por quilômetro. Qual expressão representa o preço P para x quilômetros?",
    options: ["P(x) = 6x + 2", "P(x) = 2x + 6", "P(x) = 8x", "P(x) = 2x − 6", "P(x) = x + 8"],
    correct: 1,
    explanation: "A tarifa fixa é 6 e o valor variável é 2 por quilômetro. Logo, P(x) = 2x + 6."
  },
  {
    id: 6, area: "Ciências da Natureza", subject: "Química", topic: "Ligações químicas",
    difficulty: "Médio", year: "Inédita",
    statement: "A ligação iônica ocorre, em geral, quando há:",
    options: [
      "Compartilhamento igual de elétrons entre ametais.",
      "Transferência de elétrons, formando íons de cargas opostas.",
      "Compartilhamento de prótons entre metais.",
      "Apenas forças gravitacionais entre átomos.",
      "Desaparecimento dos elétrons da eletrosfera."
    ],
    correct: 1,
    explanation: "Na ligação iônica, normalmente um átomo perde elétrons e outro ganha, formando cátions e ânions que se atraem."
  },
];

const WEEK_DAYS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"];
const AREAS = ["Matemática", "Linguagens", "Ciências Humanas", "Ciências da Natureza"];

function loadSaved() {
  try {
    const raw = localStorage.getItem("aprova-enem-v1");
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveSaved(data) {
  try {
    localStorage.setItem("aprova-enem-v1", JSON.stringify(data));
  } catch {
    // O aplicativo continua funcionando mesmo se o navegador bloquear o armazenamento.
  }
}

function ProgressBar({ value, color = "bg-blue-500" }) {
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
      <div className={`h-full rounded-full transition-all duration-500 ${color}`} style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  );
}

function StatCard({ icon: Icon, label, value, note, tone = "blue" }) {
  const tones = {
    blue: "bg-blue-500/10 text-blue-300",
    amber: "bg-amber-500/10 text-amber-300",
    green: "bg-emerald-500/10 text-emerald-300",
    violet: "bg-violet-500/10 text-violet-300",
  };
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
      <div className="flex items-center justify-between">
        <span className={`rounded-xl p-3 ${tones[tone]}`}><Icon size={20} /></span>
        <span className="text-xs text-slate-500">Seu progresso</span>
      </div>
      <p className="mt-4 text-sm text-slate-400">{label}</p>
      <p className="mt-1 text-2xl font-black text-white">{value}</p>
      <p className="mt-1 text-xs text-slate-500">{note}</p>
    </div>
  );
}

function App() {
  const saved = useMemo(() => loadSaved(), []);
  const [user, setUser] = useState(saved?.user || INITIAL_USER);
  const [activePage, setActivePage] = useState("dashboard");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [bookmarks, setBookmarks] = useState(saved?.bookmarks || []);
  const [answers, setAnswers] = useState(saved?.answers || {});
  const [completedTasks, setCompletedTasks] = useState(saved?.completedTasks || []);
  const [studyPlan, setStudyPlan] = useState(saved?.studyPlan || {});
  const [essay, setEssay] = useState(saved?.essay || "");
  const [questionSearch, setQuestionSearch] = useState("");
  const [areaFilter, setAreaFilter] = useState("Todas");
  const [difficultyFilter, setDifficultyFilter] = useState("Todas");
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [plannerOpen, setPlannerOpen] = useState(false);
  const [hoursInput, setHoursInput] = useState(user.dailyHoursGoal);
  const [daysInput, setDaysInput] = useState(user.availableDays);
  const [sessionMinutes, setSessionMinutes] = useState(25);
  const [timerRunning, setTimerRunning] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    saveSaved({ user, bookmarks, answers, completedTasks, studyPlan, essay });
  }, [user, bookmarks, answers, completedTasks, studyPlan, essay]);

  useEffect(() => {
    if (!timerRunning) return;
    const id = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          setTimerRunning(false);
          setNotice("Sessão concluída! Faça uma pequena pausa.");
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [timerRunning]);

  const filteredQuestions = useMemo(() => QUESTION_BANK.filter((q) => {
    const matchesArea = areaFilter === "Todas" || q.area === areaFilter;
    const matchesDifficulty = difficultyFilter === "Todas" || q.difficulty === difficultyFilter;
    const term = questionSearch.trim().toLowerCase();
    const matchesSearch = !term || `${q.statement} ${q.topic} ${q.subject}`.toLowerCase().includes(term);
    return matchesArea && matchesDifficulty && matchesSearch;
  }), [areaFilter, difficultyFilter, questionSearch]);

  const currentQuestion = filteredQuestions[questionIndex];
  const answeredCount = Object.keys(answers).length;
  const correctCount = Object.values(answers).filter(Boolean).length;
  const accuracy = answeredCount ? Math.round((correctCount / answeredCount) * 100) : 0;
  const totalMinutes = user.studyMinutes || 0;

  const navigate = (page) => {
    setActivePage(page);
    setMobileMenu(false);
    setNotice("");
  };

  const toggleBookmark = (id) => {
    setBookmarks((old) => old.includes(id) ? old.filter((x) => x !== id) : [...old, id]);
  };

  const confirmAnswer = () => {
    if (selectedOption === null || !currentQuestion || showExplanation) return;
    const isCorrect = selectedOption === currentQuestion.correct;
    setAnswers((old) => ({ ...old, [currentQuestion.id]: isCorrect }));
    setShowExplanation(true);
    if (isCorrect) setUser((old) => ({ ...old, xp: old.xp + 20 }));
  };

  const nextQuestion = () => {
    setSelectedOption(null);
    setShowExplanation(false);
    setQuestionIndex((i) => filteredQuestions.length ? (i + 1) % filteredQuestions.length : 0);
  };

  const savePlanner = () => {
    setUser((old) => ({ ...old, dailyHoursGoal: Number(hoursInput), availableDays: daysInput }));
    setPlannerOpen(false);
    setNotice("Seu cronograma foi atualizado.");
  };

  const toggleDay = (day) => setDaysInput((old) => old.includes(day) ? old.filter((d) => d !== day) : [...old, day]);

  const startTimer = () => {
    if (secondsLeft === 0) setSecondsLeft(sessionMinutes * 60);
    setTimerRunning(true);
  };
  const resetTimer = () => {
    setTimerRunning(false);
    setSecondsLeft(sessionMinutes * 60);
  };

  const finishSession = () => {
    setUser((old) => ({
      ...old,
      xp: old.xp + 10,
      completedSessions: old.completedSessions + 1,
      studyMinutes: old.studyMinutes + sessionMinutes,
    }));
    setSecondsLeft(sessionMinutes * 60);
    setTimerRunning(false);
    setNotice(`Sessão de ${sessionMinutes} minutos registrada. +10 XP!`);
  };

  const toggleTask = (id) => setCompletedTasks((old) => old.includes(id) ? old.filter((x) => x !== id) : [...old, id]);

  const navItems = [
    { id: "dashboard", label: "Visão geral", icon: LayoutDashboard },
    { id: "planner", label: "Cronograma", icon: CalendarDays },
    { id: "questions", label: "Questões", icon: BookOpen },
    { id: "essay", label: "Redação", icon: FileText },
    { id: "progress", label: "Meu desempenho", icon: BarChart3 },
  ];

  const pageTitle = navItems.find((n) => n.id === activePage)?.label || "Aprova ENEM";

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="flex min-h-screen">
        {mobileMenu && <button aria-label="Fechar menu" className="fixed inset-0 z-30 bg-black/60 md:hidden" onClick={() => setMobileMenu(false)} />}
        <aside className={`${mobileMenu ? "translate-x-0" : "-translate-x-full"} fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-slate-800 bg-slate-950 p-5 transition-transform md:static md:translate-x-0`}>
          <div className="flex items-center gap-3 px-2 py-3">
            <div className="rounded-2xl bg-blue-600 p-2.5 shadow-lg shadow-blue-600/20"><GraduationCap size={25} /></div>
            <div>
              <h1 className="text-lg font-black tracking-tight text-white">APROVA <span className="text-blue-400">ENEM</span></h1>
              <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-slate-500">Sua jornada começa aqui</p>
            </div>
            <button className="ml-auto text-slate-400 md:hidden" onClick={() => setMobileMenu(false)}><X size={20} /></button>
          </div>

          <div className="mt-8 rounded-2xl border border-slate-800 bg-slate-900 p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-300"><Target size={15} className="text-amber-400" /> META PRINCIPAL</div>
            <p className="mt-3 text-2xl font-black text-white">{user.targetScore} <span className="text-sm font-semibold text-slate-500">pontos</span></p>
            <p className="mt-1 text-xs text-slate-500">Objetivo de pontuação</p>
          </div>

          <nav className="mt-7 flex-1 space-y-1">
            <p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.18em] text-slate-600">Menu principal</p>
            {navItems.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => navigate(id)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-semibold transition ${activePage === id ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20" : "text-slate-400 hover:bg-slate-900 hover:text-white"}`}>
                <Icon size={18} /><span>{label}</span>{activePage === id && <ChevronRight size={16} className="ml-auto" />}
              </button>
            ))}
          </nav>

          <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-300"><Flame size={16} /> CONTINUE FIRME</div>
            <p className="mt-2 text-xs leading-relaxed text-slate-400">Pequenos avanços todos os dias constroem grandes resultados.</p>
          </div>
          <p className="mt-4 text-center text-[10px] text-slate-600">Aprova ENEM • Versão de estudos</p>
        </aside>

        <main className="min-w-0 flex-1">
          <header className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-800 bg-slate-950/90 px-4 py-4 backdrop-blur md:px-8">
            <div className="flex items-center gap-3">
              <button className="rounded-lg p-2 text-slate-300 hover:bg-slate-800 md:hidden" onClick={() => setMobileMenu(true)}><Menu size={20} /></button>
              <div>
                <p className="text-xs text-slate-500">Área do estudante</p>
                <h2 className="text-lg font-extrabold text-white">{pageTitle}</h2>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden text-right sm:block">
                <p className="text-sm font-bold text-white">{user.name}</p>
                <p className="text-[10px] text-slate-500">Nível {Math.floor(user.xp / 250) + 1} • {user.xp} XP</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full border border-blue-500/30 bg-blue-500/10 font-black text-blue-300">{(user.name || "E").slice(0, 1).toUpperCase()}</div>
            </div>
          </header>

          <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-8">
            {notice && <div className="flex items-center justify-between rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300"><span>{notice}</span><button onClick={() => setNotice("")}><X size={16} /></button></div>}

            {activePage === "dashboard" && (
              <>
                <section className="relative overflow-hidden rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950 p-6 md:p-9">
                  <div className="pointer-events-none absolute -right-10 -top-20 h-64 w-64 rounded-full bg-blue-500/10 blur-3xl" />
                  <div className="relative max-w-2xl">
                    <span className="inline-flex items-center gap-2 rounded-full border border-blue-400/20 bg-blue-400/10 px-3 py-1 text-[11px] font-bold text-blue-300"><Sparkles size={13} /> SUA CENTRAL DE PREPARAÇÃO</span>
                    <h3 className="mt-4 text-3xl font-black leading-tight text-white md:text-4xl">Olá, {user.name}!<br /><span className="text-blue-400">Vamos avançar hoje?</span></h3>
                    <p className="mt-3 max-w-xl text-sm leading-relaxed text-slate-400">Organize sua rotina, pratique questões e acompanhe sua evolução em um só lugar.</p>
                    <div className="mt-6 flex flex-wrap gap-3">
                      <button onClick={() => navigate("questions")} className="inline-flex items-center gap-2 rounded-xl bg-amber-400 px-5 py-3 text-xs font-black text-slate-950 transition hover:bg-amber-300"><Play size={15} fill="currentColor" /> COMEÇAR QUESTÕES</button>
                      <button onClick={() => navigate("planner")} className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800 px-5 py-3 text-xs font-bold text-white hover:bg-slate-700"><CalendarDays size={15} /> VER CRONOGRAMA</button>
                    </div>
                  </div>
                </section>

                <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                  <StatCard icon={Clock3} label="Tempo estudado" value={`${Math.floor(totalMinutes / 60)}h ${totalMinutes % 60}min`} note="Tempo registrado neste app" tone="blue" />
                  <StatCard icon={Flame} label="Sequência atual" value={`${user.streak} dias`} note="Mantenha a consistência" tone="amber" />
                  <StatCard icon={Trophy} label="Experiência" value={`${user.xp} XP`} note={`Nível ${Math.floor(user.xp / 250) + 1}`} tone="violet" />
                  <StatCard icon={Target} label="Questões respondidas" value={answeredCount} note={`${accuracy}% de acerto neste treino`} tone="green" />
                </section>

                <section className="grid gap-5 lg:grid-cols-3">
                  <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6 lg:col-span-2">
                    <div className="flex items-center justify-between">
                      <div><h3 className="font-extrabold text-white">Seu plano de estudos</h3><p className="mt-1 text-xs text-slate-500">Meta diária configurada</p></div>
                      <button onClick={() => navigate("planner")} className="text-xs font-bold text-blue-400 hover:text-blue-300">Abrir cronograma <ChevronRight size={14} className="inline" /></button>
                    </div>
                    <div className="mt-6 grid gap-4 sm:grid-cols-2">
                      <div className="rounded-xl bg-slate-800/70 p-4"><p className="text-xs text-slate-400">Horas por dia</p><p className="mt-1 text-2xl font-black text-white">{user.dailyHoursGoal}h</p></div>
                      <div className="rounded-xl bg-slate-800/70 p-4"><p className="text-xs text-slate-400">Dias disponíveis</p><p className="mt-1 text-2xl font-black text-white">{user.availableDays.length} dias</p></div>
                    </div>
                    <div className="mt-5"><div className="mb-2 flex justify-between text-xs"><span className="text-slate-400">Questões corretas</span><span className="font-bold text-white">{correctCount}/{answeredCount}</span></div><ProgressBar value={accuracy} color="bg-emerald-500" /></div>
                  </div>
                  <div className="rounded-2xl border border-blue-500/20 bg-blue-500/5 p-6">
                    <div className="flex items-center gap-2 text-blue-300"><Lightbulb size={18} /><h3 className="font-extrabold">Dica de estudo</h3></div>
                    <p className="mt-4 text-sm leading-relaxed text-slate-300">Resolva questões, confira os comentários e anote por que cada alternativa está certa ou errada. A revisão dos erros é parte essencial da aprendizagem.</p>
                    <button onClick={() => navigate("questions")} className="mt-5 text-xs font-bold text-blue-300 hover:text-white">Praticar agora <ChevronRight size={14} className="inline" /></button>
                  </div>
                </section>
              </>
            )}

            {activePage === "planner" && (
              <section className="space-y-5">
                <div className="flex flex-wrap items-end justify-between gap-3">
                  <div><h3 className="text-2xl font-black text-white">Cronograma semanal</h3><p className="mt-1 text-sm text-slate-400">Monte uma rotina equilibrada e realista.</p></div>
                  <button onClick={() => { setHoursInput(user.dailyHoursGoal); setDaysInput(user.availableDays); setPlannerOpen(!plannerOpen); }} className="rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-blue-500">Personalizar rotina</button>
                </div>
                {plannerOpen && <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                  <label className="block text-sm font-bold text-white">Horas disponíveis por dia: {hoursInput}h</label>
                  <input type="range" min="1" max="8" value={hoursInput} onChange={(e) => setHoursInput(Number(e.target.value))} className="mt-3 w-full accent-blue-500" />
                  <p className="mb-3 mt-5 text-sm font-bold text-white">Dias de estudo</p>
                  <div className="flex flex-wrap gap-2">{WEEK_DAYS.map((day) => <button key={day} onClick={() => toggleDay(day)} className={`rounded-lg px-3 py-2 text-xs font-bold ${daysInput.includes(day) ? "bg-blue-600 text-white" : "border border-slate-700 bg-slate-800 text-slate-400"}`}>{day}</button>)}</div>
                  <button onClick={savePlanner} className="mt-5 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-emerald-500"><Save size={14} className="mr-2 inline" />Salvar cronograma</button>
                </div>}
                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                  {WEEK_DAYS.map((day, index) => {
                    const active = user.availableDays.includes(day);
                    const suggestions = [
                      ["Matemática", "Resolver questões e revisar fórmulas"],
                      ["Linguagens", "Interpretação de texto e leitura"],
                      ["Ciências da Natureza", "Biologia, Física ou Química"],
                      ["Ciências Humanas", "História, Geografia e Sociologia"],
                      ["Redação", "Planejar, escrever e revisar um texto"],
                    ];
                    const tasks = active ? [suggestions[index % suggestions.length], suggestions[(index + 2) % suggestions.length]] : [];
                    return <div key={day} className={`rounded-2xl border p-5 ${active ? "border-slate-800 bg-slate-900" : "border-slate-900 bg-slate-950 opacity-60"}`}>
                      <div className="flex items-center justify-between"><h4 className="font-extrabold text-white">{day}</h4><span className={`h-2 w-2 rounded-full ${active ? "bg-emerald-400" : "bg-slate-700"}`} /></div>
                      {active ? <div className="mt-4 space-y-3">{tasks.map(([subject, topic], i) => {
                        const id = `${day}-${i}`;
                        const done = completedTasks.includes(id);
                        return <button key={id} onClick={() => toggleTask(id)} className="flex w-full items-start gap-3 rounded-xl bg-slate-800/70 p-3 text-left">
                          {done ? <CheckCircle2 size={17} className="mt-0.5 shrink-0 text-emerald-400" /> : <Circle size={17} className="mt-0.5 shrink-0 text-slate-500" />}
                          <span><span className="block text-xs font-bold text-blue-300">{subject}</span><span className={`mt-1 block text-xs ${done ? "text-slate-500 line-through" : "text-slate-300"}`}>{topic}</span></span>
                        </button>;
                      })}</div> : <p className="mt-6 text-sm text-slate-500">Dia livre ou de descanso.</p>}
                    </div>;
                  })}
                </div>
                <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                  <div className="flex items-center gap-2 font-bold text-white"><Timer size={18} className="text-amber-400" /> Temporizador de estudos</div>
                  <div className="mt-4 flex flex-wrap items-center gap-4">
                    <select value={sessionMinutes} onChange={(e) => { const v = Number(e.target.value); setSessionMinutes(v); setSecondsLeft(v * 60); setTimerRunning(false); }} className="rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm"><option value={15}>15 minutos</option><option value={25}>25 minutos</option><option value={45}>45 minutos</option><option value={60}>60 minutos</option></select>
                    <span className="min-w-28 text-3xl font-black tabular-nums text-white">{String(Math.floor(secondsLeft / 60)).padStart(2, "0")}:{String(secondsLeft % 60).padStart(2, "0")}</span>
                    {!timerRunning ? <button onClick={startTimer} className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-bold text-white">Iniciar</button> : <button onClick={() => setTimerRunning(false)} className="rounded-lg bg-amber-500 px-4 py-2 text-xs font-bold text-slate-950">Pausar</button>}
                    <button onClick={resetTimer} className="rounded-lg border border-slate-700 px-4 py-2 text-xs font-bold text-slate-300"><RotateCcw size={13} className="mr-1 inline" />Reiniciar</button>
                    <button onClick={finishSession} disabled={secondsLeft === sessionMinutes * 60 && !timerRunning} className="rounded-lg bg-emerald-600 px-4 py-2 text-xs font-bold text-white disabled:opacity-40">Registrar sessão</button>
                  </div>
                </div>
              </section>
            )}

            {activePage === "questions" && (
              <section className="space-y-5">
                <div><h3 className="text-2xl font-black text-white">Banco de questões</h3><p className="mt-1 text-sm text-slate-400">Pratique, confira a explicação e acompanhe seus acertos.</p></div>
                <div className="flex flex-col gap-3 rounded-2xl border border-slate-800 bg-slate-900 p-4 md:flex-row">
                  <div className="relative flex-1"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" /><input value={questionSearch} onChange={(e) => { setQuestionSearch(e.target.value); setQuestionIndex(0); setSelectedOption(null); setShowExplanation(false); }} placeholder="Buscar por assunto..." className="w-full rounded-xl border border-slate-700 bg-slate-800 py-2.5 pl-9 pr-3 text-sm text-white outline-none focus:border-blue-500" /></div>
                  <select value={areaFilter} onChange={(e) => { setAreaFilter(e.target.value); setQuestionIndex(0); setSelectedOption(null); setShowExplanation(false); }} className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-200"><option>Todas</option>{AREAS.map((a) => <option key={a}>{a}</option>)}</select>
                  <select value={difficultyFilter} onChange={(e) => { setDifficultyFilter(e.target.value); setQuestionIndex(0); setSelectedOption(null); setShowExplanation(false); }} className="rounded-xl border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-200"><option>Todas</option><option>Fácil</option><option>Médio</option><option>Difícil</option></select>
                </div>
                {currentQuestion ? <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5 md:p-7">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex flex-wrap gap-2"><span className="rounded-full bg-blue-500/10 px-3 py-1 text-[10px] font-bold text-blue-300">{currentQuestion.area}</span><span className="rounded-full bg-slate-800 px-3 py-1 text-[10px] font-bold text-slate-400">{currentQuestion.topic}</span><span className="rounded-full bg-slate-800 px-3 py-1 text-[10px] font-bold text-slate-400">{currentQuestion.difficulty}</span></div>
                    <button onClick={() => toggleBookmark(currentQuestion.id)} className="rounded-lg p-2 text-amber-300 hover:bg-slate-800" title="Salvar questão">{bookmarks.includes(currentQuestion.id) ? <BookmarkCheck size={19} /> : <Bookmark size={19} />}</button>
                  </div>
                  <p className="mt-6 text-xs font-bold uppercase tracking-wider text-slate-500">Questão {questionIndex + 1} de {filteredQuestions.length} • {currentQuestion.year}</p>
                  <h4 className="mt-3 text-base font-semibold leading-relaxed text-white md:text-lg">{currentQuestion.statement}</h4>
                  <div className="mt-6 space-y-3">{currentQuestion.options.map((option, index) => {
                    const chosen = selectedOption === index;
                    const correct = showExplanation && index === currentQuestion.correct;
                    const wrong = showExplanation && chosen && index !== currentQuestion.correct;
                    return <button key={index} disabled={showExplanation} onClick={() => setSelectedOption(index)} className={`flex w-full items-start gap-3 rounded-xl border p-4 text-left text-sm transition ${correct ? "border-emerald-500 bg-emerald-500/10 text-emerald-200" : wrong ? "border-red-500 bg-red-500/10 text-red-200" : chosen ? "border-blue-500 bg-blue-500/10 text-white" : "border-slate-700 bg-slate-800/50 text-slate-300 hover:border-slate-500"}`}>
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-current text-[11px] font-black">{String.fromCharCode(65 + index)}</span><span>{option}</span>{correct && <CheckCircle2 size={17} className="ml-auto shrink-0" />}
                    </button>;
                  })}</div>
                  {showExplanation && <div className="mt-5 rounded-xl border border-blue-500/20 bg-blue-500/5 p-4"><p className="font-bold text-blue-300">{selectedOption === currentQuestion.correct ? "Resposta correta!" : `A resposta correta é ${String.fromCharCode(65 + currentQuestion.correct)}.`}</p><p className="mt-2 text-sm leading-relaxed text-slate-300">{currentQuestion.explanation}</p></div>}
                  <div className="mt-6 flex flex-wrap justify-between gap-3">
                    <span className="self-center text-xs text-slate-500">{answers[currentQuestion.id] === undefined ? "Ainda não respondida" : answers[currentQuestion.id] ? "Você acertou esta questão" : "Você errou esta questão"}</span>
                    {!showExplanation ? <button disabled={selectedOption === null} onClick={confirmAnswer} className="rounded-xl bg-blue-600 px-5 py-3 text-xs font-bold text-white disabled:cursor-not-allowed disabled:opacity-40">Confirmar resposta</button> : <button onClick={nextQuestion} className="rounded-xl bg-blue-600 px-5 py-3 text-xs font-bold text-white">Próxima questão <ChevronRight size={14} className="ml-1 inline" /></button>}
                  </div>
                </div> : <div className="rounded-2xl border border-slate-800 bg-slate-900 p-8 text-center text-slate-400">Nenhuma questão encontrada com esses filtros.</div>}
                <p className="text-xs leading-relaxed text-slate-600">Observação: este projeto contém questões demonstrativas inéditas, não um banco oficial do INEP. O percentual de acertos exibido é apenas um indicador simples e não representa uma nota TRI.</p>
              </section>
            )}

            {activePage === "essay" && (
              <section className="space-y-5">
                <div><h3 className="text-2xl font-black text-white">Laboratório de redação</h3><p className="mt-1 text-sm text-slate-400">Escreva, salve e revise seu texto dissertativo-argumentativo.</p></div>
                <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
                  <label className="mb-2 block text-sm font-bold text-white" htmlFor="essay-theme">Tema da redação</label>
                  <input id="essay-theme" placeholder="Ex.: Desafios para a inclusão digital no Brasil" className="mb-4 w-full rounded-xl border border-slate-700 bg-slate-800 px-4 py-3 text-sm text-white outline-none focus:border-blue-500" />
                  <label className="mb-2 block text-sm font-bold text-white" htmlFor="essay-text">Seu texto</label>
                  <textarea id="essay-text" value={essay} onChange={(e) => setEssay(e.target.value)} placeholder="Digite sua redação aqui..." rows={16} className="w-full resize-y rounded-xl border border-slate-700 bg-slate-800 p-4 text-sm leading-7 text-slate-200 outline-none focus:border-blue-500" />
                  <div className="mt-3 flex flex-wrap items-center justify-between gap-3"><span className="text-xs text-slate-500">{essay.trim() ? essay.trim().split(/\s+/).length : 0} palavras • {essay.length} caracteres</span><div className="flex gap-2"><button onClick={() => setEssay("")} className="rounded-lg border border-slate-700 px-3 py-2 text-xs font-bold text-slate-400 hover:text-white"><Trash2 size={13} className="mr-1 inline" />Limpar</button><button onClick={() => setNotice("Redação salva neste dispositivo.")} className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-bold text-white"><Save size={13} className="mr-1 inline" />Salvar redação</button></div></div>
                </div>
                <div className="grid gap-3 md:grid-cols-2">
                  {["Competência 1 — domínio da escrita formal", "Competência 2 — compreensão do tema", "Competência 3 — seleção e organização dos argumentos", "Competência 4 — uso dos mecanismos linguísticos", "Competência 5 — proposta de intervenção"].map((item) => <div key={item} className="rounded-xl border border-slate-800 bg-slate-900 p-4 text-sm text-slate-300"><NotebookPen size={16} className="mb-2 text-blue-400" />{item}</div>)}
                </div>
                <p className="text-xs leading-relaxed text-slate-600">A redação fica salva no armazenamento local deste navegador. A correção automática por IA ainda precisa de uma integração segura com um serviço de backend.</p>
              </section>
            )}

            {activePage === "progress" && (
              <section className="space-y-5">
                <div><h3 className="text-2xl font-black text-white">Seu desempenho</h3><p className="mt-1 text-sm text-slate-400">Acompanhe os dados registrados durante o uso do aplicativo.</p></div>
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                  <StatCard icon={BookOpen} label="Respondidas" value={answeredCount} note="Questões únicas" tone="blue" />
                  <StatCard icon={CheckCircle2} label="Acertos" value={correctCount} note="Respostas corretas" tone="green" />
                  <StatCard icon={Target} label="Aproveitamento" value={`${accuracy}%`} note="Acertos ÷ respondidas" tone="amber" />
                  <StatCard icon={Clock3} label="Tempo de estudo" value={`${totalMinutes} min`} note="Sessões registradas" tone="violet" />
                </div>
                <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
                  <h4 className="font-extrabold text-white">Questões por área</h4>
                  <div className="mt-5 space-y-5">{AREAS.map((area) => {
                    const ids = QUESTION_BANK.filter((q) => q.area === area).map((q) => q.id);
                    const done = ids.filter((id) => answers[id] !== undefined).length;
                    const right = ids.filter((id) => answers[id] === true).length;
                    return <div key={area}><div className="mb-2 flex justify-between text-xs"><span className="font-semibold text-slate-300">{area}</span><span className="text-slate-500">{right}/{done} acertos</span></div><ProgressBar value={done ? right / done * 100 : 0} color="bg-blue-500" /></div>;
                  })}</div>
                </div>
                <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
                  <h4 className="font-extrabold text-white">Questões salvas</h4>
                  {bookmarks.length ? <div className="mt-4 space-y-2">{QUESTION_BANK.filter((q) => bookmarks.includes(q.id)).map((q) => <div key={q.id} className="flex items-center justify-between gap-3 rounded-xl bg-slate-800/70 p-3"><div><p className="text-xs font-bold text-blue-300">{q.subject} • {q.topic}</p><p className="mt-1 line-clamp-2 text-xs text-slate-300">{q.statement}</p></div><button onClick={() => toggleBookmark(q.id)} className="p-2 text-slate-500 hover:text-red-300"><Trash2 size={16} /></button></div>)}</div> : <p className="mt-3 text-sm text-slate-500">Você ainda não salvou nenhuma questão.</p>}
                </div>
                <button onClick={() => { if (window.confirm("Tem certeza de que deseja apagar seu progresso salvo neste dispositivo?")) { setAnswers({}); setBookmarks([]); setCompletedTasks([]); setUser((u) => ({ ...u, xp: 0, studyMinutes: 0, completedSessions: 0 })); setNotice("Progresso reiniciado."); } }} className="rounded-xl border border-red-500/30 px-4 py-2.5 text-xs font-bold text-red-300 hover:bg-red-500/10"><RotateCcw size={14} className="mr-2 inline" />Reiniciar progresso</button>
              </section>
            )}

            <footer className="border-t border-slate-900 pt-5 text-center text-[10px] text-slate-600">Aprova ENEM • Organize seus estudos, pratique e evolua.</footer>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
