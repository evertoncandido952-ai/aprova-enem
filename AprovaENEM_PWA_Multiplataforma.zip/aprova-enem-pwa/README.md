# Aprova ENEM — PWA multiplataforma

Este projeto é um aplicativo web progressivo (PWA). Depois de publicado em um endereço HTTPS, pode ser instalado em Android, iPhone/iPad e computadores compatíveis, sem criar um app nativo separado para cada sistema.

## Executar localmente

Requer Node.js 18 ou superior.

```bash
npm install
npm run dev
```

Para gerar a versão de produção:

```bash
npm run build
npm run preview
```

O conteúdo compilado fica na pasta `dist/`.

## Publicar para instalar em outros dispositivos

1. Envie esta pasta para um repositório GitHub.
2. Importe o repositório em um serviço de hospedagem estática, como Vercel, Netlify ou Cloudflare Pages.
3. Use `npm run build` como comando de build e `dist` como pasta de saída.
4. Abra o endereço HTTPS publicado no dispositivo desejado e instale/adiciona à tela inicial.

## Instalação por plataforma

- Android (Chrome/Edge): menu do navegador → Instalar app ou Adicionar à tela inicial.
- iPhone/iPad (Safari): Compartilhar → Adicionar à Tela de Início.
- Windows (Edge/Chrome): ícone Instalar na barra de endereço ou menu do navegador.
- macOS (Chrome/Edge): menu do navegador → Instalar página como app. O Safari no Mac tem suporte diferente; pode-se usar o site normalmente.
- Linux (Chrome/Chromium/Edge): menu do navegador → Instalar app, quando disponível.

## Observações importantes

- A instalação depende de hospedagem HTTPS (localhost funciona apenas para testes).
- O service worker armazena o app shell e recursos visitados para melhorar a experiência offline. A primeira abertura precisa de internet.
- O progresso fica no armazenamento local do navegador/dispositivo. Ele não sincroniza automaticamente entre aparelhos.
- O código ainda não tem contas/login, sincronização em nuvem, banco oficial do INEP nem correção de redação por IA. Não coloque uma chave privada de API no frontend; uma integração de IA deve passar por um backend seguro.
- Questões incluídas são demonstrativas e inéditas, não questões oficiais do ENEM.
